# Wrap Up


I hope you got exited about the possibility of sending messages in an easy and secure way. That's of course not the end of this course, but rather just the beginning. At the moment we have been focusing on confidentiality, but there are other important security goals in communication systems that we will explore as the course advance. 


## Your task 

RSA was published in the 1977 by Ron Rivest, Adi Shamir, and Leonard Adleman. It is considered one of the most elegant combination of Number theory (a field within Pure Mathematics) and Computational complexity (a field within Computer Science). Therefore,I encourage you to increase your theoretical knowledge on RSA by reading Chapter 9.3 of the book "A classical introduction to cryptography" by Serge Vaudenay. 




