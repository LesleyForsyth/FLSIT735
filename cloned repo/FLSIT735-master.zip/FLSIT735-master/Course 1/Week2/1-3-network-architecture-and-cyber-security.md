# Effect of the Network Architecture on Cyber Security

Network architecture is a coceptual model that uses set of communication protocols for communication over the internet and simillar computer networks. What happens if everyone follows their own rules to communicate over the internet?




## Think questions
After exploring OSI network model and TCP/IP protocol suit, Layered abstraction helps to increase the security in our networks? If yes then how? If no then, what can we do to optimise the security of the overall network. Do we need a new network protocol suit which outperforms the existing TCP/IP protocol suit? or TCP/IP is the ultimate solution for the future?



